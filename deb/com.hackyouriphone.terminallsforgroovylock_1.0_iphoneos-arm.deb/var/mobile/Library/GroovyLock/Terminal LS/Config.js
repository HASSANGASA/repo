
var textColor = "green"; //use words such as red, blue, etc, or use hex #ffffff, #67c446, etc. Settings require respring.
var bgColor = "black"; //use words such as red, blue, etc, or use hex #ffffff, #67c446, etc.
var fontStyle = false; //turn on to use system font, if you have bytafont it will use bytafont font.
var bgImage = false; //If you would like to use an image as a bg, place the image in var/mobile/library/GroovyLock/Terminal LS/image.jpg
